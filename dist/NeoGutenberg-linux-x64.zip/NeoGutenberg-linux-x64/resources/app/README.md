# NeoGutenberg

A Printing press for the digital age.

------
### About

NeoGutenberg is a free ebook redaction tool. The author simply writes markdown, presses a button and ebooks are generated.

### Features

* Work with markdown instead of HTML like other ebook generation tools.
* Outputs to ePub and mobi
* Add a custom style to your books using scss
* More coming soon...
* Free
* Themeable editor
* Cross-Platform

For more information, please visit the [NeoGutenberg website](https://atnpgo.github.io/NeoGutenberg/)
